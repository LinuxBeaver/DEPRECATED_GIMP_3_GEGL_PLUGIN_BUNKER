#!/bin/bash

gio trash */build


